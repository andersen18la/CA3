import React, { Component } from 'react';
import './App.css';

class App extends Component {
	rows = [];
	constructor(props) {
		super(props);
		this.state = {
			person: [],
			inputField: "",
			inputWeek: ""
		};
	}
	
	render() {
		return (
			<div className="App"> 
				<div className="creadential-div">
					<h1>Home Page</h1>
					<div className="input-div">
						<input type="text" placeholder="Enter City Name" value={this.state.inputField} onChange={evt => this.setState({inputField:evt.target.value})} /> &nbsp;
						<input type="number" placeholder="Enter Week Number" value={this.state.inputWeek} onChange={evt => this.setState({inputWeek:evt.target.value})} /><br/>
					</div>

					<table className="user-detail-table"> 
						<thead>
							<tr>
								<th>ID</th>
								<th>City</th>
								<th>Street</th>
								<th>Zip</th>
								<th>Description</th>
								<th>ImageURI</th>
								<th>GEO</th>
								<th>Rating</th>
								<th>Week</th>
								<th>Availability</th>
							</tr>
						</thead>
						<tbody>
							{
								this.state.person.map((user,index) => {
									if((user.city.indexOf(this.state.inputField)!=-1 || this.state.inputField == '') && (JSON.stringify(user.week).indexOf(this.state.inputWeek)!=-1 || this.state.inputWeek == '') ){ 
										return <tr key={index}>
										<td>{user.id}</td>
										<td>{user.city}</td>
										<td>{user.street}</td>
										<td>{user.zip}</td>
										<td>{user.description}</td>
										<td>{user.imageUri}</td>
										<td>{user.geo}</td>
										<td>{user.rating}</td>
										<td>{user.week}</td>
										<td>{JSON.stringify(user.available)}</td>
									</tr>
									} else {
										return;
									}
								})
							}
						</tbody>
					</table>
				</div>
			</div>
		);
	}
	
	componentDidMount() {    
		var url = 'http://localhost:4000/places';
		fetch(url, {
			method: 'GET',
			headers: {
				Accept: 'application/json',
			},
		},
		).then(response => {
			if (response.ok) {
				response.json().then(json => {
					console.log(json);
					this.setState({person: json})
					console.log(this.state.person);
				});
			}
		});
	}

}
export default App;
