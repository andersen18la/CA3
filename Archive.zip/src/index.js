import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import * as firebase from 'firebase';

var config = {
    apiKey: "AIzaSyAysrOYyNxd3AJs8MaPKN9cm6FesqOPXjo",
    authDomain: "login-project-965de.firebaseapp.com",
    databaseURL: "https://login-project-965de.firebaseio.com",
    projectId: "login-project-965de",
    storageBucket: "",
    messagingSenderId: "1037221192387"
  };
  firebase.initializeApp(config);

ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
